from django.urls import include, path,re_path
from GreenBuildingManagement import views

urlpatterns = [        
    path('get_gbm_devices_list', views.Green_list),
    # path('green_building_manage_device_list/<int:pk>', views.green_detail),
    
    path('get_token_of_airveda', views.GetToken),
    
    path('get_refresh_token_of_airveda', views.refrece_token),
    
    path('get_last_hour_data_of_airveda', views.lastData),
    
    path('get_device_data_of_airveda', views.lastDeviceData),
    
    
    path('Green_data_list', views.Green_data_list),
    
    
    
    
]