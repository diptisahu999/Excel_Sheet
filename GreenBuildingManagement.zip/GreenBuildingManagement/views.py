from django.shortcuts import render
from GreenBuildingManagement.models import BmsGreenBuildingManageDevice,BmsGreenBuildingData
from GreenBuildingManagement.serializers import BmsGreenBuildingManageDeviceSerializer,BmsGreenBuildingManageDataSerializer
from rest_framework.response import Response 
from rest_framework.decorators import api_view
from rest_framework import status
# Create your views here.
import requests
import time



# Bms_Module crud
token = []
@api_view(['GET', 'POST', 'DELETE'])
# @permission_classes([IsAuthenticated])
def Green_list(request):
    if request.method == 'GET':
        bms_module = BmsGreenBuildingManageDevice.objects.all()        
        bms_module_serializer = BmsGreenBuildingManageDeviceSerializer(bms_module, many=True)
        return Response({"data":"true","status_code": 200, "message": "Green Building Manage Device Lists", "response":bms_module_serializer.data},status=status.HTTP_200_OK)
    
 
    elif request.method == 'POST':
        module_serializer = BmsGreenBuildingManageDeviceSerializer(data=request.data)
        if module_serializer.is_valid():
            module_serializer.save()
            return Response({"data":"true","status_code": 200, "message": "Green Building Manage Device Added Sucessfuly!!","response":module_serializer.data},status=status.HTTP_201_CREATED) 
        return Response({"status_code":401,"responce":module_serializer.errors},status=status.HTTP_400_BAD_REQUEST) 
    
    elif request.method == 'DELETE':
        count = BmsGreenBuildingManageDevice.objects.all().delete()
        return Response({'message': '{} Green Building Manage Device was deleted successfully!'.format(count[0])}, status=status.HTTP_204_NO_CONTENT)
    
    
    
@api_view(['GET', 'POST', 'DELETE'])
# @permission_classes([IsAuthenticated])
def Green_data_list(request):
    if request.method == 'GET':
        bms_module = BmsGreenBuildingData.objects.all()        
        bms_module_serializer = BmsGreenBuildingManageDataSerializer(bms_module, many=True)
        return Response({"data":"true","status_code": 200, "message": "Green Building Manage Device Lists", "response":bms_module_serializer.data},status=status.HTTP_200_OK)
    
    elif request.method == 'POST':
        module_serializer = BmsGreenBuildingManageDataSerializer(data=request.data)
        if module_serializer.is_valid():
            module_serializer.save()
            return Response({"data":"true","status_code": 200, "message": "Green Building Manage Device Added Sucessfuly!!","response":module_serializer.data},status=status.HTTP_201_CREATED) 
        return Response({"status_code":401,"responce":module_serializer.errors},status=status.HTTP_400_BAD_REQUEST) 
    
    
 
# @api_view(['GET', 'PUT', 'DELETE'])
# # @permission_classes([IsAuthenticated])
# def green_detail(request, pk):
#     try: 
#         bms_module = BmsGreenBuildingManageDevice.objects.get(pk=pk) 
#     except BmsGreenBuildingManageDevice.DoesNotExist: 
#         return Response({'message': 'The Green Building Manage Device does not exist'}, status=status.HTTP_404_NOT_FOUND) 
         
 
#     if request.method == 'GET': 
#         module_serializer = BmsGreenBuildingManageDeviceSerializer(bms_module) 
#         return Response({"data":"true","status_code": 200, "message": "Green Building Manage Device Get Successfully", "response":module_serializer.data},status=status.HTTP_200_OK)  
 
#     elif request.method == 'PUT': 
#         module_serializer = BmsGreenBuildingManageDeviceSerializer(bms_module, data=request.data) 
#         if module_serializer.is_valid(): 
#             module_serializer.save() 
#             return Response({"data":"true","status_code": 200, "message": "Green Building Manage Device updated Sucessfuly!!","response":module_serializer.data},status=status.HTTP_201_CREATED) 
#         return Response({"status_code":401,"responce":module_serializer.errors},status=status.HTTP_400_BAD_REQUEST)  
         
 
#     elif request.method == 'DELETE': 
#         bms_module.delete() 
#         return Response({'message': 'Green Building Manage Device was deleted successfully!'}, status=status.HTTP_204_NO_CONTENT)
    
    
@api_view(['GET', 'POST', 'DELETE'])
# @permission_classes([IsAuthenticated])
def GetToken(request):
    if request.method == 'GET':
        token.clear()
        bms_module = BmsGreenBuildingManageDevice.objects.all()        
        # print(bms_module.values())
        data_user= bms_module.values()
        a = data_user[0]['user_name']
        # print(a)
       
        base_api = data_user[0]['api_key']
        data = {
        "email": data_user[0]['user_name'],
        "password": data_user[0]['password']
        }
        
        response = requests.post(str(base_api),json=data)
        data = response.json()
        token.append(data)
        # My_data = {"idToken":data['idToken']}
        # {"idToken":data['idToken']}
        
        return Response({"data":"true","status_code": 200, "message": "Get Token Lists", "response":data} ,status=status.HTTP_200_OK)
    
    

import requests
from datetime import datetime, timedelta

@api_view(['GET', 'POST', 'DELETE'])
# @permission_classes([IsAuthenticated])
def refrece_token(request):
    if request.method == 'GET':
        bms_module = BmsGreenBuildingManageDevice.objects.all()        
        print(bms_module.values())
        data_user = bms_module.values()
        a = data_user[0]['user_name']
        # print(a)
        data_user[0]['password']
        base_api = data_user[0]['api_key']

        expiration_time = datetime.now() + timedelta(seconds=15)  # Set token expiration time to 3 minutes

        data = {
            "email": data_user[0]['user_name'],
            "password": data_user[0]['password'],
            "expiration_time": expiration_time.strftime('%Y-%m-%d %H:%M:%S')
        }
        
        response = requests.post(str(base_api), json=data)
        data = response.json()
        # My_data = {"refreshToken":data['refreshToken']}
        return Response({
            "data": "true",
            "status_code": 200,
            "message": "Get Refresh Lists",
            "response": data
        }, status=status.HTTP_200_OK)



@api_view(['GET','POST', 'DELETE'])
# @permission_classes([IsAuthenticated])
def lastData(request):
    if request.method == 'GET':
        bms_module = BmsGreenBuildingManageDevice.objects.all()        
        # print(bms_module.values())
        data_user= bms_module.values()
        a = data_user[0]['model_no']
        # print(token[0]['idToken'])
        # data = request.data
        # idToken= data['idToken']
        # token = ""
        last_token = token[0]['idToken']
        
        # device_id = data['device_id']
        base_api = 'https://dashboard.airveda.com/api/data/last-hour/'
    
        
        headers = {
            'Authorization': f'Bearer {last_token}',
            'Content-Type': 'application/json'
        }
        data = {
            "deviceId":a
        }

        response = requests.post(base_api, headers=headers, json=data)
        device_data = response.json()
        # print(device_data)
        return Response({
            "data": "true",
            "status_code": 200,
            "message": "Get Device data Lists",
            "response": device_data
        }, status=status.HTTP_200_OK)
        
        
        

@api_view(['GET','POST', 'DELETE'])
# @permission_classes([IsAuthenticated])
def lastDeviceData(request):
    if request.method == 'GET':
        bms_module = BmsGreenBuildingManageDevice.objects.all()        
        # print(bms_module.values())
        data_user= bms_module.values()
        a = data_user[0]['model_no']
        # print(token[0]['idToken'])
        # data = request.data
        # idToken= data['idToken']
        # token = ""
        last_token = token[0]['idToken']
        
        # device_id = data['device_id']
        base_api = 'https://dashboard.airveda.com/api/data/last-hour/'
    
        
        headers = {
            'Authorization': f'Bearer {last_token}',
            'Content-Type': 'application/json'
        }
        data = {
            "deviceId":a
        }

        response = requests.post(base_api, headers=headers, json=data)
        device_data = response.json()
        print(device_data)
        
        aqi = device_data['data']
        print(aqi)
        
        data={
                "aqi": aqi,
                "pm25": 37,
                "pm10": 78,
                "co2": 882,
                "voc": 185,
                "temperature": 25.4,
                "humidity": 55,
                "battery": 5,
                "time": "2023-07-18 04:14:28",
                "viral_index": 82
            }
        
        module_serializer = BmsGreenBuildingManageDataSerializer(data=data)
        # print(module_serializer)
        return Response({
            "data": "true",
            "status_code": 200,
            "message": "Get Device data Lists",
            "response": device_data
        }, status=status.HTTP_200_OK)
        
        
        